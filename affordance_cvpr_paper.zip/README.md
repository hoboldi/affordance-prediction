# CVPR 4-page paper — Overleaf import

Source for *"Where Do Verbs Live on a Shape? Spatial Message Passing and the
Limits of Generalization in Verb-Conditioned 3D Affordance Prediction."*

## Files in this zip
- `main.tex` — the paper (two-column CVPR format).
- `references.bib` — bibliography.
- `figures/` — teaser (GNN vs MLP), verb-overlap heatmap, cross-category (LOCO), few-shot.

## Import into Overleaf (recommended path — gives you cvpr.sty)
`main.tex` uses `\usepackage{cvpr}`; that style file ships with the CVPR author
kit, **not** with texlive/Overleaf by default. So:

1. In Overleaf: **New Project → Templates**, search **"CVPR 2024"** (or 2025) and
   create a project from it — this gives you `cvpr.sty` and `ieee_fullname.bst`.
2. Upload `main.tex` (replace the template's), `references.bib`, and the
   `figures/` folder.
3. Compile with **pdfLaTeX**. For a review (line-numbered) build, change
   `\usepackage{cvpr}` to `\usepackage[review]{cvpr}`.

*Alternative:* upload this zip directly as a new project, then add `cvpr.sty` +
`ieee_fullname.bst` from the CVPR author kit — otherwise it won't find the style.

## Notes
- All numbers are from the cleaned 226-object, 5-fold protocol.
- Target length is 4 pages. It has 4 figures + 4 tables and may run slightly over;
  to trim, the natural levers (in order) are: drop the few-shot figure, merge
  Tables 2 & 3, then shorten Related Work.
